    package com.example.inclusive.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import com.example.inclusive.R
import com.example.inclusive.databinding.ActivityMainBinding

    class MainActivity : AppCompatActivity() {

        private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val spLista: Spinner= findViewById(R.id.spinner_1)
        val spLista2: Spinner= findViewById(R.id.spinner_2)
        val showtext:EditText=findViewById(R.id.showText)
        val edittext:EditText=findViewById(R.id.editText)

        val adp=ArrayAdapter.createFromResource(this,R.array.Lista,android.R.layout.simple_spinner_item)
            .also{adapter->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
                spLista.adapter = adapter
                spLista2.adapter = adapter
        }


    }
}


