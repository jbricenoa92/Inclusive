package com.example.inclusive.utils

class ListOptions {


    fun listElementToConvert(option:String):List<String>{
    var option1:String
    val options= listOf<String>("Español", "Braille", "Dactolológico")
        return options
    }
}